def get_data(num: int):
    heap = []
    if num == 0:
        print("Heap tree is empty")
        return heap
    elif num == 1:
        heap.append(int(input("Enter element: ")))
        print(heap)
        return heap
    else:
        for i in range(num):
            heap.append(int(input("Enter element: ")))
            
        return heapify(num, heap)
    
def heapify(num: int, heap):
    # Build the max heap from the list in a bottom-up manner
    for i in range((num // 2) - 1, -1, -1):
        max_heapify(heap, num, i)
    return heap 

def max_heapify(heap, n, i):
    # Maintain the max-heap property for the subtree rooted at index i
    largest = i  # Initialize largest as root
    left = 2 * i + 1  # left child
    right = 2 * i + 2  # right child
    
    # If left child exists and is greater than root
    if left < n and heap[left] > heap[largest]:
        largest = left
    
    # If right child exists and is greater than the current largest
    if right < n and heap[right] > heap[largest]:
        largest = right
    
    # If largest is not root
    if largest != i:
        heap[i], heap[largest] = heap[largest], heap[i]  # Swap
        max_heapify(heap, n, largest)  # Recursively heapify the affected subtree

def parent(i):
    return (i - 1) // 2

def heap_sort(num: int, heap):
    # Convert the list into a max heap
    heapify(num, heap)
    
    for i in range(num - 1, 0, -1):
        heap[0], heap[i] = heap[i], heap[0]  # Swap the root of the heap with the last element
        max_heapify(heap, i, 0)  # Restore the heap property for the reduced heap size
    
    return heap[::-1]  # Since we have a max heap, we reverse to get the sorted array

if __name__ == "__main__":
    num = int(input("Enter the number of elements in the heap: "))
    heap = get_data(num)
    if heap:
        sorted_list = heap_sort(len(heap), heap)
        print("Sorted array:", sorted_list)
