# Create a list of all odd numbers between 1 and a max number. Max number is something you need to take from a user using input() function

max = int(input("Enter any integer number: "))
num = max
Odd_list = [1]
j = 1

if max%2 == 0: # If the entered number is even 
    for i in range(1, num-1):
        Odd_list.insert(j, j+1)
        j = j+1

else: # if the entered number is odd
    for i in range(1, num-1):
        Odd_list.insert(j, j+2)
        j = j+1

print(Odd_list)

# Good Code 
max = int(input("Enter max number: "))

odd_numbers = []

for i in range(1, max):
    if i % 2 == 1:
        odd_numbers.append(i)

print("Odd numbers: ", odd_numbers)