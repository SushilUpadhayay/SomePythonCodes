"""def heap():
    num = int(input("Enter numnber of elements in the heap tree: "))
    heap_tree = []
    for i in range(num):
        heap_tree.append(int(input("Enter element: ")))
        
        if heap_tree[int((i - 1)/2)] < heap_tree[i] and i != 0: # If right child is greater
            heap_tree[int((i - 1)/2)], heap_tree[i] = heap_tree[i], heap_tree[int((i - 1)/2)] # Swapping        
        elif heap_tree[int((i - 2)/2)] < heap_tree[i] and i  != 0: # If left child is greater
            heap_tree[int((i - 2)/2)], heap_tree[i] = heap_tree[i], heap_tree[int((i - 1)/2)] # Swapping
        else:
            pass
    for i in range(num):
        if heap_tree[int((i - 1)/2)] < heap_tree[i] and i != 0: # If right child is greater
            heap_tree[int((i - 1)/2)], heap_tree[i ] = heap_tree[i], heap_tree[int((i - 1)/2)] # Swapping   
             
        elif heap_tree[int((i - 2)/2)] < heap_tree[i] and i != 0: # If left child is greater
            heap_tree[int((i - 2)/2)], heap_tree[i] = heap_tree[i ], heap_tree[int((i - 1)/2)] # Swapping
            
        else:
            pass
    print(heap_tree)
if __name__ == "__main__":
    heap()"""
    
def heap():
    """
    Creates a max heap from user input and prints the resulting heap structure.

    Optimizations:
        - Combined element insertion and heapification in a single loop for efficiency.
        - Used a single swap logic for both left and right child comparisons (cleaner).
        - Removed unnecessary negation (i != 0) for clarity (assuming indexing starts at 0).
        - Considered potential edge cases (empty heap or single element) for robustness.
    """

    num = int(input("Enter number of elements in the heap tree: "))
    heap_tree = []

    # Handle empty heap or single element case
    if num == 0:
        print("Empty heap")
        return
    elif num == 1:
        heap_tree.append(int(input("Enter element: ")))
        print(heap_tree)
        return

    for i in range(num):
        value = int(input("Enter element: "))
        heap_tree.append(value)

        # Efficiently swap up the newly added element for heap property
        while i > 0 and heap_tree[i] > heap_tree[parent(i)]:
            heap_tree[i], heap_tree[parent(i)] = heap_tree[parent(i)], heap_tree[i]
            i = parent(i)

    print(heap_tree)
    print(len(heap_tree))

def parent(i):
    """
    Calculates the parent index for a given index in a heap structure.
    """
    return (i - 1) // 2  # Integer division for floor operation means returns integer value

if __name__ == "__main__":
    heap()