# Debug and complete it

class node:
    def __init__(self, data = None, next = None): # The default data and next pointer values of the newly created node is null
        self.data = data  # If value is provided then it will be replaced
        self.next = next  # If value is provided then it will be replaced

class linked_list:
    def __init__(self):
        self.head = node() # meaning that head is a node with no data and next field 
    
    def insert_begin(self, data):
        new_node = node(data, self.head) # If it is a very first node then its next field will have None value and if it is not then its next field will have the pointer to the previous node
        self.head = new_node
    
    def insert_last(self, data):
        ptr = self.head # Will point to the first node 
        if self.head is None:
            self.insert_begin(data)
            return 
        
        while ptr.next != None: # Runs untill ptr holds the pointer to the last node 
            ptr = ptr.next
        new_node = node(data) # new_node will have data but it's next field will have None value as it is a last node
        ptr.next = new_node # the previous last node will hold the pointer to this new_node
    
    def length(self):
        ptr = self.head
        len = 0
        while ptr.next != None:
            ptr = ptr.next
            len += 1
        return len
    '''  def insert_random(self, data):
        index = int(input("Enter the index at which you want to insert a new node: "))
        new_node = node(data)
        
        if index == 0: # If the node is to be inserted to the begining
            self.insert_begin(data)
            return 
        
        # At any point, index starts with 0 and if the index is 2 then ptr will have 1 less position of node according to the given index
        ptr = self.head # Will point to the first node 
        current_index = 0  
        while ptr.next != None and current_index < index - 1:
            ptr = ptr.next
            current_index = current_index + 1
        
        if ptr.next is None:
            print("Index out of bound!!")
            return 
        
        new_node.next = ptr.next  
        ptr.next = new_node
        print(ptr.data)
 '''           
    
    def display(self):
        ptr = self.head
        elems = []
        while ptr .next !=None: # Understand the loop
            ptr = ptr.next
            elems.append(ptr.data)
        print(elems)
        

        
if __name__ == "__main__":
    l1 = linked_list()
    l1.insert_begin(58)
    l1.insert_begin(89)
    l1.insert_last(30)
   # l1.insert_random(50)
    print(l1.length())
    l1.display()