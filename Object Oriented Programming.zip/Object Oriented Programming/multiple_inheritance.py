class Flyable:
    def fly(self):
        print("Flying")

class Swimmable:
    def swim(self):
        print("Swimming")

class Walkable:
    def walk(self):
        print("Walking")

class Amphibian(Flyable, Swimmable, Walkable):
    def amphibian_activity(self):
        print("Engaging in amphibian activities")

# Creating an object of the most derived class
frog = Amphibian()

# Accessing properties and methods from the entire inheritance hierarchy
frog.fly()  # Calls the method in the first base class (Flyable)
frog.swim()  # Calls the method in the second base class (Swimmable)
frog.walk()  # Calls the method in the third base class (Walkable)
frog.amphibian_activity()  # Calls the method in the most derived class (Amphibian)
