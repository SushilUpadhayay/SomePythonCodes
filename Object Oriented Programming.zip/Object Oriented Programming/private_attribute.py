class Hello():
    def __init__(self, name: str):
        self.__name = name # The double underscore makes the name attribute a private attribute meaning that it can't be accessed from outside of the class
    
    def __say_hello(self): # private attribute ( a method can also be called a attribute)
        print(f"Hello {self.__name}! You seems to be a good programmer. ") # I included  double underscore before the name attribute while printing mesaage as this function is calling via another  method 
    
    def get_name(self): # creating a method that will return a private attribute named 'name'. 
        return self.__name
    
    def get_say_hello_fun(self):
        return self.__say_hello()

if __name__ == "__main__":
    
    H = Hello("Sushil")
    print(H.__name) # This will show error as:- AttributeError: 'Hello' object has no attribute '__name'
    H.say_hello()  # This will show error as:- AttributeError: 'Hello' object has no attribute 'say_hello'
    print(H.get_name()) # prints 'Sushil'
    H.get_say_hello_fun()
    