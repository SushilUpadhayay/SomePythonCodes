from abc import ABC, abstractclassmethod # ABC = Abstract Base Class
# A abstract class is one that has atleast one abstract method as its member function which shortens the code and increases the code reuseability
# Abstract class provides a blueprint that needs to be followed by the child classes.
# Child classes must contain or override the abstract methods.
# Generally, we don't create the objects of abstract class.
# Abstract methods inside the abstract class should't contain any sort of statements except comment statements.
# Abstract class supports polymorphism
class Person(ABC):
    @abstractclassmethod
    def Name(self, name): # A abstract method
        pass

    @abstractclassmethod
    def age(self, year): # Another abstract method
        pass

    @abstractclassmethod
    def display(self):
        pass

class Student(Person):

    def Name(self, name):
        self.name = name
       
    def age(self, year):
        self.year = year

    def ID(self, id):
        self.id = id

    def display(self):
        print(f"My name is {self.name}.")
        print(f"You are {self.year} years old.")
        print(f"Your student id is {self.id}.")


class Teacher(Person):

    def Name(self, name):
        self.name = name

    def age(self, year):
        self.year = year

    def salary(self, amount):
        self.amount = amount
    
    def display(self):
        print(f"My name is {self.name}.")
        print(f"You are {self.year} years old.")
        print(f"Your salary is {self.amount}.")

# person = Person() Error! because we can't create a object of a abstract class
student = Student()
student.Name("Sushil")
student.age(26)
student.ID(206789516)
student.display()

print("Details of a teacher!")
teacher = Teacher()
teacher.Name("Aakash")
teacher.age(26)
teacher.salary(30000)
teacher.display()
