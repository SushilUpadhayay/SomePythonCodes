class Animal:
    def __init__(self, species):
        self.species = species

    def make_sound(self):
        print("Some generic animal sound")

class Mammal(Animal):
    def __init__(self, species, has_fur):
        super().__init__(species)
        self.has_fur = has_fur

    def feed_milk(self):
        print("Feeding milk to the young")

class Dog(Mammal):
    def __init__(self, breed, has_fur):
        super().__init__("Dog", has_fur)
        self.breed = breed

    def make_sound(self):  # Overrides the make_sound method in the base class
        print("Woof! Woof!")

    def bark_at_mailman(self):
        print("Barking at the mailman")

# Creating an object of the most derived class
my_dog = Dog(breed="Labrador", has_fur=True)

# Accessing properties and methods from the entire inheritance hierarchy
print(f"My dog belongs to the {my_dog.species} species.")
print(f"Does my dog have fur? {'Yes' if my_dog.has_fur else 'No'}")
my_dog.make_sound()  # Calls the overridden method in the derived class
my_dog.feed_milk()  # Calls the method in the intermediate class
my_dog.bark_at_mailman()  # Calls the method in the most derived class
