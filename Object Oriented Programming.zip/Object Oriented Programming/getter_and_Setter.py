class Employee:
   
    @property
    def age(self):
        print("Getter is called.")
        return self._age
    
    @age.setter
    def age(self, age):
        print("Setter is called.")
        self._age = age
    
    @age.deleter
    def age(self):
        print("Deleter is called")
    
if  __name__ == "__main__":
    emp = Employee()
    emp.age = 23 # this will call the setter, since age is private aatribute this will raise error if there is no property decorator
    print(emp.age) # This will call the getter and this will aslo raise error if there is no any property decorator because we are trying to access attribute outside of the class
    
  
# This can also be done using property() function as 
"""

class Employee:
   
    def get_age(self):
        print("Getter is called.")
        return self._age
        
    def set_age(self, age):
        print("Setter is called.")
        self._age = age
        
    def del_age(self):
        print("Deleter is called")
        
    age =  property(get_age, set_age, del_age) # Three agruments getter(), setter() and deleter(). The property decorator is used to preserve the encapsulation property of a class
    
if  __name__ == "__main__":
    emp = Employee()
    emp.age = 23 # this will call the setter
    print(emp.age) # This will call the getter
    
"""