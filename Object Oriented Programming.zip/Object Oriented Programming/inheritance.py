# Base class (Superclass)
class Vehicle:
    def __init__(self, brand, model):
        self.brand = brand
        self.model = model

    def start(self):
        print("Vehicle started.")

    def stop(self):
        print("Vehicle stopped.")

# Subclass (Derived class)
class Car(Vehicle): # Single Inheritance
    def __init__(self, brand, model, num_doors):
        # Calling the constructor of the base class
        super().__init__(brand, model)
        self.num_doors = num_doors

    def honk(self):
        print("Honk! Honk!")

# Creating instances of the classes
my_car = Car(brand="Toyota", model="Camry", num_doors=4)

# Accessing attributes and methods from the base class
print(f"My car is a {my_car.brand} {my_car.model}.")
my_car.start()

# Accessing attributes and methods from the derived class
print(f"My car has {my_car.num_doors} doors.")
my_car.honk()

# Calling a method from the base class
my_car.stop()
