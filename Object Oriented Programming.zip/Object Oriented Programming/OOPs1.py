# creating a class

class Vehicle:
    wheels = 4 # class variable or static variable, shared by all objects, this is the default value assigned to class variable
    def __init__(self): # constructor function
        print("This is a constructor!.")

    def start_car(self, eng_displacement):
        self.eng_displacement = eng_displacement # we need to link the variable eng_displacement as member variable otherwise it will be treated as local variable
        print(f"{eng_displacement} engine is started.")

    def move(self):
        print('Car is started to move.')
    
    def stop(self, brake):
        print(f"{brake} brake is applied to car to stop the car.")
        print(f"{self.eng_displacement} engine is started.")

car = Vehicle()
motorcycle = Vehicle()
car.start_car("V10")
car.move()
car.stop("6 piston")
car.wheels = 5 # this will not updates the class variable, it will create a instance variable named 'wheels' specific to the 'car' object and assigs a value of 5 instead
Vehicle.wheels = 6 # class variable updated
print(f"Car has {car.wheels}.")
print(f"General wheels of vehicle is {Vehicle.wheels}.") # Directly access the class variable
print(f"motorcycle has {motorcycle.wheels} wheels.") # This line correctly accesses the class variable wheels for the motorcycle object.
print(f"{car.eng_displacement} engine is started.") #can be accessed outside the class

""" we can create a attribute specific to a object or instance meaning that it does not need to be the attribute of other instances of that class
for example: if we have two instances such as laptop and phone with attributes 'name' and 'price' then we can assign a attribute 'numpad' specfic to laptop only because a phone does
not has or need a numpad and we can do this as:

laptop.has_numpad = True



"""