"""class Rectangle:
    pass
class Square(Rectangle):
    def __init__(self, length: float, width: float):
        self.length = length
        self.width = width
    
    def area(self):
        return self.length*self.width
    
class cube(Rectangle):
    def __init__(self, length: float, width: float, height: float):
        self.length = length
        self.width = width
        self.height = height
    
    def volume(self):
        return self.length*self.width*self.height
    
""" 
# super() function in python used in the case when there is similar codes that are in child class
# Meaning that similar code can be written only once in the heigh level class and can be reused in the child class as well
# Although inheritance allows access of methods of parent class by the child class the super() allows the access of those lines 
# of code that can be similar to all the class and every other child class can add extra lines of code including the existing code 
# In the above code all the shapes share attributes such as length and width and cube shape also has attribute named height therefore
# all the sub class can share the method of the super class to initialize their instance attributes and can add other attributes of their own
# So above code with use of super()

class Rectangle:
    def __init__(self, length: float, width: float):
        self.length = length
        self.width = width
        
    def area(self):
        return self.length*self.width
    
class Square(Rectangle):
    def __init__(self, length: float, width: float):
        super().__init__(length, width)
    
class Cube(Rectangle):
    def __init__(self, length: float, width: float, height: float):
        super().__init__(length, width)
        self.height = height
    
    def volume(self):
        return self.area()*self.height
    
if __name__ == "__main__":
    square = Square(4, 5)
    print("Area of square is: ", square.area())
    
    cube = Cube(4, 5, 6)
    print("Volume of cube is: ", cube.volume())
    
 
