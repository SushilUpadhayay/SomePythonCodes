class Hello:
    def hello (self):
        print("Hello ", end = " ")

class World(Hello):
    def __init__(self):
        super().hello()  # Call the hello() of the base class. We can also transfer arguments as well.
        print("World!")

helloworld = World() # calls the child class constructor 
# this is useful when child class function overrides the base class function or you need a common function that can be placed in base class