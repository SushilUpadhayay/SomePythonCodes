class Animal:
    def speak(self):
        print("Animal speaks")

class Dog(Animal):
    def speak(self):  # Overrides the speak method in the base class
        print("Dog barks")

class Cat(Animal):
    def speak(self):  # Overrides the speak method in the base class
        print("Cat meows")

# Creating objects of the derived classes
dog = Dog()
cat = Cat()

# Accessing the overridden methods
dog.speak()  # Calls the overridden method in the Dog class
cat.speak()  # Calls the overridden method in the Cat class
