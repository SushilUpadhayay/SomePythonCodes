
class Item:

    pay_rate = 0.8 # Class attribute, shared by all the variable
    all = [] # to store all of the instance of the class Item
    def __init__(self, name: str, price: float, quantity = 0): # here we can understand variables 'name', 'price', 'quantity' as attributes that must be possed by a object to be an valid object of the class item
                                                               # here 'name' attribute is only accepting a string, 'price' attribute can accept both integer as well as float value quantity is initialized to 0 (default value)that means it is a integer variable
        # Just Like SQL we can also user assertions in python for example received values of price and quantity must be positive 
        assert price >= 0, "Price is not positive" # prints the specified message whenever the price is negative
        assert quantity >= 0, "Quantity is not positive" # If there are no assert error statements then the compiler will simply prints'AssertionError'
        
        self.name = name                              
        self.price = price
        self. quantity = quantity

        # code to store instances
        Item.all.append(self)
    
    def cal_total(self):
        return self.price * self.quantity
    
    def apply_dis(self):
        self.price = self.price * self.pay_rate # If we use Item in place of self.pay_rate then all the items will receive 20% discounts
    
    # method releated to print name of all instanecs without using for loop but using a magic method
    def __repr__(self):
        return f"Item('{self.name}', {self.price}, {self.quantity})"
    
   

"""item1 = Item('Phone', 150, 1)
# print("The total price of object item1 is", item1.cal_total());

item2 = Item('laptop', 3000, 5)
item2.has_numpad = True # It is the variable specific to object item2 only
item2.pay_rate = 0.7 # Customer buying laptop receives 30% discount
# print("The total price of object item2 is", item2.cal_total());

# print(Item.pay_rate) # Accessing the class attribute by class
# print(item1.pay_rate) # Accessing the class attribute by instance item1
# print(item2.pay_rate) # Accessing the class attribute by instance item2

# print(Item.__dict__) # Prints the dictionary of attributes assigned to class Item i.e. class variable
# print(item2.__dict__) # Prints the dictionary of attributes assigned to instance item1, here __dict__ is called magic attribute but __init__ is called magic method


item2.apply_dis()
print(item2.price) """


# Next Chapter


for i in Item.all:
    print(i.name) # prints name of all instances
print(Item.all) # prints  name of all instances along with their attribute's values 
