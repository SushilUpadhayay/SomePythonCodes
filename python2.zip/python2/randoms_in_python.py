import random
x = random.randint(1,6) # returns a random integer from  1 to 6
print(x)


random_float = random.random() # returns a random float from 0 to 1
print(random_float)


random_number = random.uniform(2.5, 5.5) # returns a random float from 2.5 to 5.5
print(random_number)

my_list = [1, 2, 3, 4, 5]
random_element = random.choice(my_list) # returns a random element from 'my_list'
print(random_element)


my_list = [1, 2, 3, 4, 5] # returns a shuffled list
random.shuffle(my_list)
print(my_list)


unique_random_integers = random.sample(range(1, 11), 6)
print(unique_random_integers)




