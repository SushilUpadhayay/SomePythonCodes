set1 = {1, 2, 3, 4, 5}
set2 = {2, 4, 6, 8, 10, 12}
union_set = set1.union(set2) # Or union_set = set1 & set2
print(union_set) # Result: {1, 2, 3, 4, 5}

intersection_set = set1.intersection(set2) # Or intersection_set = set1 & set2
print(intersection_set) # Result: {2, 4}


set1 = {1, 2, 3}
set2 = {3, 4, 5}
difference_set = set1.difference(set2) # or difference_set = set1 - set2
print(difference_set) # Result: {1, 2}



