# Creating a dictionary
my_dict = {"name": "John", "age": 30, "city": "New York"} # Three key value pairs

# Accessing values using keys
name = my_dict["name"]  # "John"
age = my_dict["age"]  # 30

# Modifying values
my_dict["age"] = 31

# Adding a new key-value pair
my_dict["country"] = "USA"

# Removing a key-value pair
del my_dict["city"]

# some operations that can be done in dictionary
print(my_dict.get("gulariya")) # Return the value for key if key is in the dictionary, else default. Checks if key is present or not
print(my_dict.keys()) # returns all the keys in dictionary 'my_dict'
print(my_dict.items()) # returns all the key:value pairs in dictionary 'my_dict'
print(my_dict.values()) # returns all the values in dictionary 'my_dict'
print(my_dict.update({'sex':'male'})) # Mutable---not only we can add the new key:value pair, we can also modify the existing key:value pair
my_dict.pop('name') # removes the value from dictionary using coressponding
# my_dict.clear() removes everything from dictionary

print("\n")
# Iterating through a dictionary
for key, value in my_dict.items():
    print(key, value)
