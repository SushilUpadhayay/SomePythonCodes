try:
    # Code that might raise an exception
    num = int(input("Enter a number: "))
    result = 10 / num
except ZeroDivisionError as e:
    # Handle the ZeroDivisionError exception
    print("You cannot divide by zero.")
    print(e)
except ValueError as e:
    # Handle the ValueError exception (e.g., if the user enters a non-integer)
    print("Please enter a valid integer.")
    print(e)
else:
    # Code to execute when no exception occurred
    print("Result:", result)
finally:
    # Cleanup code (optional, always executed)
    print("Execution complete.")
