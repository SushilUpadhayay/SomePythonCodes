


# python program to swap two values from list

def interchange(my_list):
    length = len(my_list)
    temp = my_list[0]
    my_list[0] = my_list[length-1]
    my_list[length-1] = temp
    return my_list
    
print("This is the python program swapping first and last elements of list.")
my_list = []

while True:
   element = input("If you want to continue then enter element otherwise type 'done'.")
   if element == 'done':
      break
   my_list.append(element)

if not my_list:
   print("There is nothing to swap.")
else:
   print(f"Your list before swap: {my_list}")
   print(f"List after swapping: {interchange(my_list)}")
    
