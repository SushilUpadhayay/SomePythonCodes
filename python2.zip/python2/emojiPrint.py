print('\U0001F600')
"""Put uniode of emoji inside the double or single quotes and replace plus sign with
three zeros and place a backslash before opening quotes"""
#For unicode type unicode of emojis on search bar
print("\U0001F923")