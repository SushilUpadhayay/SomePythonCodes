name = input("What is your name?")
print(name.upper())

user_input = input("Enter your age: ") # int(input("Enter your age: "))---------for shorter execution--------only enter a whole number otherwise error
user_input = int(user_input) # input is typecasted to integer using int function
user_input+= 1 # this is not possible if the input is in string
print("You entered your age:", user_input)