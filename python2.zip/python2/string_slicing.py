# making a new substring out of a string by slicing or selecting certain characters of oriniginal string
# for this we can use indexing [start:end:step] or slice() function
original_string = "Hello Sushil!"
string0 = original_string[3:] # the character at index 3 (when started from 0) will be included in the substring
string1 = original_string[0:5:2] # H and l(H,e) and o(l,i)-----Hlo
string2 = original_string[::2] # HloSsi!--- 
# if start or end or step index hasn't been mentioned, default values are used as start=0,end=index of last character+1,step=1 (step can't be zero)
string3 = original_string[6:] # end is set to default
string4 = original_string[0:-5] # The slicing operation, original_string[0:-5], includes characters from the beginning (index 0) up to, but excluding, 
# the character that is 5 positions from the end (index -5). So, the result is "Hello Su".
string5 = original_string[::-1] # to reverse a string use negative step index
string6 = original_string[-7:-1] # starting from 7 through end and ending from -1 through end

print(string0)
print(string1)
print(string2)
print(string3)
print(string4)
print(string5)
print(string6)


"""*******using slice() function"""
text = "Hello, World!"

# Create a slice object
my_slice = slice(0, 5)  # Equivalent to text[0:5]

# Apply the slice object to the string
substring = text[my_slice]  # Result: "Hello"
print(substring)


