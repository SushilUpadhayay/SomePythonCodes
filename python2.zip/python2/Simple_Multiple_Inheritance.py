class Staff:
    def __init__(self):
        self.name = int(input("Enter name: "))
        self.code = int(input("Enter code: "))
        
    def display(self):
        print(f"Name: {self.name}.")
        print(f"Code: {self.code}.")
         
class Teacher(Staff): # Error or ambiguity solve this
    def __init__(self):
        super().__init__(self)
        self.subject = str(input("Enter subject: "))
        self.publication = int(input("Enter publication: "))
        
    def disforteacher(self):
        super().display(self)
        print(f"Subject: {self.subject}.")
        print(f"Publication: {self.publication}.")
    
class Officer(Staff):
    def __init__(self):
        super().__init__(self)
        self.grade = str(input("Enter grade: "))
    
    def disforofficer(self):
        super().display(self)
        
class Typist(Staff):
    def __init__(self):
        super().__init__(self)
        self.speed = float(input("Enter typing speed: "))
        
    def display2(self):
        super().display(self)
        print(f"Speed: {self.speed}.")
        
class Regular(Typist):
    def __init__(self):
        super().__init__(self)
        
    def disforregular(self):
        super().display(self)
    
class Casual(Typist):
    def __init__(self):
        super().__init__(self)
        self.daily_wages = float(input("Enter daily wage: "))
    
    def disforcasual(self):
        super().display2(self)
        print(f"Daily wage: {self.daily_wages}.")

if __name__ == "__main__":
    print("Enter details of teachers: ")
    T = Teacher()
    
    print("Enter details of officers: ")
    O = Officer()
    
    print("Enter details of regular typists: ")
    R = Regular()
    
    print("Enter details of casual typists: ")
    C = Casual()
    
    print("Details of teachers: ")
    #T.disforteachers()
    
    print("Details of officers: ")
    O.disforofficer()
    
    print("Details of regular typist: ")
    R.disforregular()
    
    print("Details of casual typist: ")
    C.disforcasual()



