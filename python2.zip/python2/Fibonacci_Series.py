if __name__ == "__main__":
    a = int(input("Enter the length of the fibonacci series: "))
    b = 1
    c = 0
    for i in range(a):
        s= c + b
        b = c
        c = s
        print(f"{s}+") # How we stop print in next line ??
        
        