import math # math module is similar to header file <math.h> in c and c++
print(math.pi) # prints value of pi
value = 3.5123469758632152
print(round(value,2))
print(math.ceil(value)) # rounds off to the closest integer 
print(math.floor(value)) # removes decimal point
print(abs(value)) # prints absolute value
print(pow(value,2)) # power---also value**2thuis can be used
print(math.sqrt(144)) # finds out square root of a number
x=123
y=456
z=90
a=20.369
print(max(x,y,z,a)) # prints max out of these numbers
print(min(x,y,z,a)) # prints min out of these numbers