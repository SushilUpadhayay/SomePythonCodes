#  Method chaining, also known as cascading or fluent interface, is a programming technique where multiple methods can be called on an object in a single line. 
# This is achieved by having each method return the modified object (usually self), allowing subsequent methods to be called on the result of the previous method.

class Print_outs:

    def print1(self):
        print("Hello",end = " ,")
        return self
    
    def print2(self, name):
        self.name = name
        print(f"{name}",end = " ")
        return self
    
    def print3(self):
        print("How are you?")
        return self

Pouts = Print_outs()
Pouts.print1().print2("Sushil").print3()