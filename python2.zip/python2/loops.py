cont = input("Do you want to continue the loop? ")
while cont == "yes":
    name = input("Enter your name? ")
    age = int(input("Enter your age? "))
    if age<=16:
        print("Go study!!")
    cont = input("Do you want to continue the loop? ")

# for loops in python

for i in range(10): # initializes i from 0 to 9
    print(i)
print("\n\n")
for i in range(1,10): # but if range is set to range(1,10), loops start from 1 to 9
    print(i)

numbers = [1, 2, 3, 4, 5]

for number in numbers: # prints number from 1 to 5
    print(number)
print("\n\n")
for num in range(2,10,2): # prints number from 1 to 9 but skips two numbers everytime
    print(num)
print("\n\n")

# Generate a sequence of numbers from 10 down to 1 when 'step' is set to negative
for num in range(10, 0, -1):
    print(num)
# controlling the for loops using string
text = "Hello, World!"

for character in text: # for loop iterates through each of the character treating each character as an element in  the sequence 
    if character.isalpha():
       print("Alphabet character: ",character) # print(f"Alphabet character: {character}") 
    elif character.isspace(): 
        print("Space character")
    else:
        print(f"Non-alphabet character: {character}")


for i in range(10,-1,-1):
    print(i)
    if i==0:
        print("Congratulation!!!!")


    


    