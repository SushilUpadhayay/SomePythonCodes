# use non recursive search technique becoz it says 'maximum recursive depth is reached'.

def search(left, right, temp_list, key):
    mid = (left + right)//2
    val = 1

    if temp_list[mid] == key:
        print(f"Value is found at index {mid}.")
        val += 1
        return
    elif temp_list[mid] > key:
        search(left, mid-1, temp_list, key)
    else:
        search(mid+1, right, temp_list, key)
    
    if val == 1:
        print("Value doesnot exist in this list.")


print("This is the program to search a element on the list given the value of element to search.")
i = 1
my_list = []

while True:
    element = input(f"If you want to add {i}th element then type your element otherwise type 'done': ")
    my_list.append(element)
    i += 1

    if element == 'done':
        my_list.remove('done')
        break

my_list.sort()
print(f"List after sorting {my_list}.")

if 0 == len(my_list): # if there is atleast one element then len will give 1 not 0
    print("List is empty.")
else:
    key = input("Enter the element you want to search in list: ")
    search(0, len(my_list)-1, my_list, key)



