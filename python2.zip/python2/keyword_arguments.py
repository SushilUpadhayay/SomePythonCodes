def print_name(first, middle, last):
    print('Hello' + " " + first + " " +middle + " " + last + ".")

print_name('sushil', 'kumar', 'upadhayay') # postional arguments where order of passing arguments matters

def print_name(first, middle, last):
    print('Hello' + " " + first + " " +middle + " " + last + ".")

print_name(last = 'upadhayay', middle = 'kumar', first = 'Sushil') # keyword arguments where order of arguments doesn't matter