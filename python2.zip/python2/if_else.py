citizen = input("What is your country's name? ")
home = input("What is your hometoun? ")
if citizen == "Nepal" or (home == "Bardiya"): # either one of the condition needs to be true for and---'not' changes true into false and viceversa
    print("Congratulation!!!You are Nepali.")
elif citizen == "America" and (home == "Alabama"): # elif shorter for else if----both condition needs to be true
    print("You are American but")
else:
    print("You are neither Nepali nor American citizen.")

# All comperison prompt is same as in C and C++. Note that only one if, elif or else statement is executed out of all
# there is also a logical operater called 'not'
 