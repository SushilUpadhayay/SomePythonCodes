import time
print(f"Now, countdown start{'\U0001F600'}!!!!")
for i in range(10,0,-1):
    time.sleep(1)
    print(i)
    if i==1:
        print("Naya barsa ko shuvakama sabailai!!!!!")

print("This statement runs immediately")

time.sleep(2)  # Pause for 2 seconds

print("This statement runs after a 2-second delay")

# No time.sleep() here, so the next statement runs immediately
print("This statement runs immediately")

