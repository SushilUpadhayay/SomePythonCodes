def main():
    try:
        with open("file_handling_test.txt", 'w') as fwrite:
            content = input("Write anything you want to include in file: ")
            fwrite.write(content)
    
    except FileNotFoundError:
        print("That file you are looking to write is not found! :(")

    try:
        with open("file_handling_test.txt", 'r') as fread:
            print(fread.read())
    except FileNotFoundError:
        print("That file from which you are looking to read from is not found! :(")

main()