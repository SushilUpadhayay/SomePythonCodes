def area(a, b, c):
    s=(a+b+c)/2
    if (a+b)<=c or (a+c)<=b or (c+b)<=a or  a<=0 or b<=0 or c<=0:
        print("Invalid data")
        return
    else:
        A=(s*(s-a)*(s-b)*(s-c))**(1/2)
        print("The area is ",A)

if __name__ == "__main__":
 a = float(input("Enter first number: "))
 b = float(input("Enter second number: "))
 c = float(input("Enter third number: "))
 area(a,b,c)	
	
