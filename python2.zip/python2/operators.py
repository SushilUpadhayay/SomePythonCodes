print("The addition of 2 and 3 is: ",2+3)
print("The multiplication of 2 and 3 is: ",2*3)
print("The subtraction of 2 and 3 is: ",2-3)
print("The division  of 2 by 4 is: ",2/4) # this is called float division
print("The division of 2 by 3 is: ",2//3) # this is called integer division
print("The square of 2 is: ",2**2)
print("the underroot of 2 is: ",2**0.5)
# to round off the number use round()------>round(digit_you_want_to_round_off,the_number_upto_which_you_wants_roundoff)
print("the underroot of 2 is: ",round(2**0.5,5))
