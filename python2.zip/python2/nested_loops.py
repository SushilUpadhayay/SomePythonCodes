for i in range(5): # number of rows
    for j in range(5):
        print("*", end="") # The print("*", end="") statement is used to print an asterisk (*) without adding a newline character at the end.
    print("")
