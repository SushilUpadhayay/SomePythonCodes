
#no need to declare a variables,it's datatype will automatically declared by interperator
# welcome_sushil_in_gulariya----->snake case writing------we should use this form of writing in python
# welcomeSushilInGulariya----->camel case writing(first letter small as usual)-----we shouls use this type of writing in java
print(len("sushil")) #returns the length of string

"""*********Upper case conversion*************"""

# Using the str.upper() method on a string literal
print(str.upper("sushil"))

# Using the str.upper() method on a variable
a = "sushil"
b = a.upper()
print(b)

# Using the str.upper() method directly on a string literal
print("sushil".upper())



"""*********Lower case conversion*************"""

# Using the str.upper() method on a string literal
print(str.lower("SUSHIL"))

# Using the str.upper() method on a variable
a = "SUSHIL"
b = a.lower()
print(b)

# Using the str.upper() method directly on a string literal
print("SUSHIL".lower())

#removes spaces from front and back of a string
original_string = "  Hello, World!"
stripped_string = original_string.strip()

print("Original String:", original_string)
print("Stripped String:", stripped_string)



"""*********string concatenation*************"""

# Create a list of strings
words = ["Hello", "world", "my", "name", "is", "sushil"]

# Use the str.join() method to join the list of words with a space separator
result =" ".join(words)

# Print the result
print(result)
#another method
a="sushil"
b="upadhayay"
c=a+b 
print("Name: ",c)
#to space out the two strings
d="Robair"
e="Aakash"
f=d+" "+e
print("Name: ",f)





"""*************Replace string or substring*********"""

original_string = "I like to eat apples. apples are delicious."
new_string = original_string.replace("apples",'a',1)

print(new_string)



"""*******Checking that is there are letters only in string*******"""
string1 = "HelloWorld"
string2 = "123"
string3 = "Hello, World!"
string4 = "Hello123"
string5 = "Hello123World"
b = string5.isalpha()
print(str.isalpha("HelloWorld"))  # True (only contains letters)
print(string2.isalpha())  # False (contains digits)
print(string3.isalpha())  # False (contains a comma and space)
print(string4.isalpha())  # False (contains alphabets with letters)
print(b)                  # False (contains alphabets and letters)


"""*********To find substring in a string************"""
string1 = "Hello! My name is Sushil.My other name is Robair"
print(string1.find("name")) #we can also find out the index of character in substring within a string



"""*****To find out the number of substring in a string****"""
original_string = "She sells seashells by the seashore."
substring = "se"

count = original_string.count(substring) # or "se in place of substring variable"

print("Number of occurrences of 'se':", count)


"""*******To find out if threre is all numbers in a string****"""
numeric_string1 = "12345"
numeric_string2 = "42.75"
non_numeric_string = "Hello123"

print(numeric_string1.isnumeric())  # True (contains only numeric digits)
print(numeric_string2.isnumeric())  # False (contains a decimal point)
print(non_numeric_string.isnumeric())  # False (contains letters)

"""*******String manipulations****"""
string1 = "Hello"
string2 = "World"
string3 = "3"
string4 = string1 + " " + string2 + " " + string3
print(string4)
print(string1*3)








