#\\ this is double backslash
print("\\\\ This is double backslash")
#these are /\/\/\/\/\ mountain
print("thise are /\\/\\/\\/\\/\\ mountain")
#he is      awesome
print("He is \t\t awesome")
#\" \n \t \'
print("\\\" \\n \\t \\\'")
#if we use r before the double or single quote, escape sequences are treated as normal string
print(r"This is not backslash \n")