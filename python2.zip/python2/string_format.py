"""def print_name(name):
    print("My name is {}. Nice to meet you!".format(name))
    text = "My name is {}. Nice to meet you!"
    print(text.format(name)) 
    print("My name is {:10}. Nice to meet you!".format(name)) # left alingment----default
    print("My name is {:<10}. Nice to meet you!".format(name)) # left alingment
    print("My name is {:>10}. Nice to meet you!".format(name)) # right alingment
    print("My name is {:^10}. Nice to meet you!".format(name)) # centre alingment

print_name("Sushil")"""

# number formatting

import math
num = math.pi
number = 1000
print(num)
print("The number is {:.3f}.".format(num)) # prints only three digits after period; round() function also can be used
print("The number is {:e}.".format(number)) # prints the scienctific value of number
print("The number is {:,}.".format(number)) # places comma ',' in every digits after thousand place 

num = 42 # same for binary ('b') and hexadecimal ('X')
octal_representation = format(num, 'o')
print(f"The octal representation of {num} is {octal_representation}.")
