import os
file_path = "D:\\SelfPractice\\draftForself.c"

if os.path.exists(file_path): # checks whether the path exists or not
    print("This path exists!")
    if os.path.isfile(file_path): # checks ehether that file exists or not in that path
        print('This is a file!')
    elif os.path.isdir(file_path): # checks ehether that folder exists or not in that path
        print("This is a folder!")
    else:
        print("this is neither a folder nor a file!")
else:
    print("This path doesn't exist!")