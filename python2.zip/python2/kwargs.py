def print_details(**kwargs):
    for key, value in kwargs.items(): # iterating through dictionary
        print(value, end = ' ')

print_details(name = 'Sushil', age = 21, gender = 'male') # key:value arguments