fruits = ["apple", "guava", "banana", "apple", "dragonfruit", "mango", "Litchy", "orange"] # declaration and initialization of list
print(fruits[2]) # accessing the element of list using index
print("\n\n")
fruits[2] = "grape" # we can also change the element of list later on the program
print(fruits[2])
print("\n\n")
fruits.append("kiwi") # appends a element at the end of the list
fruits.pop() # removes the element from last
fruits.insert(0,"pineapple") # inserts the element at the specified index and backs the element one step backward after the index element
fruits.sort()
fruits.remove("apple") # removes the first occurence of element from the list

for x in fruits:
    print(x)

# to reverse a list

my_list = [25, 89, 78, 90, 23, 34]
my_list.reverse() # it modifies the existing list, not returns the reversed list so don't use it like print(my_list.reverse())
print(my_list)

my_list2 = my_list[::-1]
print(my_list2)