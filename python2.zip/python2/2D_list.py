drinks = ["apple_juice", "red_wine", "coffee", "tea"]
dinner = ["bhaat", "roti", "chicken_burger", "salad", "corn_flakes"]
dessert = ["ice-cream", "pudding", "lassi", "jalebi"]
food = [drinks,dinner,dessert]
print(food) # prints the entire food list
for row in food:
    for column in row:
        print(column)
    print()

print(food[0][3]) # prints third elent from 0th list(drinks)