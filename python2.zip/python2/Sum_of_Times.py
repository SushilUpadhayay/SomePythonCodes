class Time:
    def __init__(self):
        self.hr = float(input("Enter time in hour: "))
        self.min = float(input("Enter time in min: "))
        self.sec = float(input("Enter time in sec: "))
        
    def display(self):
        print(f"Your time in hour:minute:second format is: {self.hr}:{self.min}:{self.sec}")
    
    def sum(self,t1,t2): 
        self.sec=(t2.sec+t1.sec)%60
        self.min=(t2.sec+t1.sec)/60
        self.hr=(t2.min+t1.min)/60
        self.min=self.min+(t2.min+t1.min)%60
        self.hr=self.hr+(t2.hr+t1.hr)
  
if __name__ == "__main__":
    t1 = Time()
    print("Enter second Time: ")
    t2 = Time()
    t3 = Time()
    t3.sum(t1,t2) # How we stop the execution of constructor ?? 
    print("Sum of these times is: ")
    t3.display()
