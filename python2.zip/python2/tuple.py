my_tuple = ('sushil', 21, 'male') # Tuple
# my_tuple[0] = 'robair' this will so error
# some basic pre build functions of tuple
print(my_tuple.count('sushil')) # counts the no. of 'sushil' appeared in tuple 'my_tuple'
print(my_tuple.index('sushil')) # prints the index number of 'sushil' in tuple 'my_tuple'

# iterating through tuple
for x in my_tuple:
    print(x)

# checking that a certain elements is present in tuple or not
if 21 in my_tuple:
    print(f"The age of {my_tuple[0]} is {my_tuple[1]}.")


# Accesing elements of tuple because it is indexed
my_tuple = (20, 50, 30)
sum2 = my_tuple[0] + my_tuple[1] + my_tuple[2]
print(sum2)