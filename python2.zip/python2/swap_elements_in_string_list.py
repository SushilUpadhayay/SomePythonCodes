# *************using replace() + list comprehension***************

my_list = ['Gfg', 'is', 'best', 'for', 'Geeks'] # initializing a list

print("Original list: ", my_list)

# using list comprehension
swapped_list = [sub.replace('G', '-').replace('e', 'G').replace('-', 'e') for sub in my_list]

print("Swapped_list: ", swapped_list) 






# *********Using join() + replace() + split()*******************

test_list = ['Gfg', 'is', 'best', 'for', 'Geeks']
 
# printing original lists
print("The original list is : " + str(test_list))
 
# Swap elements in String list
# using replace() + join() + split()
res = ", ".join(test_list) # converts list into string and separates them with ','
print(res)
res = res.replace("G", "_").replace("e", "G").replace("_", "e").split(', ') # splits the strings into list of substring after every comma ','
 
# printing result 
print ("List after performing character swaps : " + str(res)) # str(res) is used because you cannot concatenate a string with list.So, it converts the list into string