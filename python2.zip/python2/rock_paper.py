import random
    
choices = ['rock', 'paper', 'scissor']

player = input("rock or paper or scissor?: ").lower() # .lower() to convert input into lower case

while player not in choices: # whenever player choses the invalid choice
   player = input("PLease input valid choice: ").lower()

Computer_choice = random.choice(choices)

print("Computer: ",Computer_choice)

# Comparing the choices 
while True:
 
 if player == Computer_choice:
    print("Same choices,Draw")

 elif player == 'rock' and Computer_choice == 'paper':
    print("Computer won :)")

 elif player == 'rock' and Computer_choice == 'scissor':
    print("You won :)")
 
 elif player == 'paper' and Computer_choice == 'rock':
    print("You won :)")

 elif player == 'paper' and Computer_choice == 'scissor':
    print("Computer won :)")

 elif player == 'scissor' and Computer_choice == 'rock':
    print("Computer won :)")

 elif player == 'scissor' and Computer_choice == 'paper':
     print("You won :)")

 # asking if the user wants to go for another around
 user_input = input("If you want to go for another round then enter your choice and if not type any other key: ")

 if not user_input in choices:
    break
