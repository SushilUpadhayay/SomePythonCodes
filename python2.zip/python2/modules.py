"""
Two types:
-Pre_written modules are available with in the python programming
-A module contains functions or classes defined in it.These functions and classes can be imported into a main programming file
for thr reuseability, modularity of program.
"""
# help("modules") # Lists all the pre_written modules including python files that you have created in this directory

import message # A different file containing add() and subtract()
result = message.add(2, 4)
print("The sum is: ", result)
result2 = message.subtract(5, 2)
print("The subtraction is: ", result2)