# Construtor in multiple inheritance
# We have to explicitly call the base class constructor in multiple inheritance
class A:
    def __init__(self):
        print("Constructor of class A")

class B:
    def __init__(self):
        print("Constructor of class B")

class C(A, B): # multiple inheritance
    def __init__(self):
        A.__init__(self)  # Calls the constructor of class A
        B.__init__(self)  # Calls the constructor of class B
        print("Constructor of class C")

# Creating an object of the derived class
obj = C()

# For single inheritance we can use the statement super().__init__self() to call the base class constructor. It is also lnown as super function