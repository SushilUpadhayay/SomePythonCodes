import sys

questions = {
             "When did the python was created?" : "A",
             "Who created the python?" : "C",
             "What is Python?" : "D",
             "Does Pokhara University teaches Python?" : "D",
             "Which programming language is teached first in Pokhara University?" : "A"
}

answers = [[ "A. 1991", "B. 2003", "C. 1969", "D. 1800s"], 
          [ "A. John F. Kennedy", "B. Donald Trump", "C. Guido van Rossum", "D. Dennis MacAlistair Ritchie" ],
          [ "A. A programming language", "B. Snake", "C. Reptile", "D. All of the above"],
          [ "A. Yes", "B. I don't know", "C. Maybe", "D. No"], 
          [ "A. C", "B. C++", "C. JAVA", "D. Python"]]

# score
def score():
    pass


            
# new_game
def new_game():
    a = input("To play the game, type 'y' otherwise type 'n': " ).lower()

    if a == 'y':
        p_name = input("Enter your name? ")
        q_answer(p_name)
    
    else:
        sys.exit()


# ask questions and checks answers
def q_answer(p_name):
    score = 0
    question_num = 0
    for key,value in questions:
        print(key)
        question_num += 1

        for i in answers:
            print(i)
            user_ans = input("Enter your answer: ").uppercase()

            if user_ans == value:
                print("You are right. ")
                score += 1
            else:
                print("You are wrong. ")
    # new_game()

"""# player's information
def info():
    pass"""


new_game()



