print("Hello world\nhello sushil") 
print('I\'m sushil')
print("I\"m sushil")
print("I\"m sushil")
#print("This is backslash\") This will show error
print("This is backslash\\")
print("This is  double backslash\\\\") 
print("Sush\bil")
# print('hello world') use ctrl+/ for comment and again use this for uncomment it

