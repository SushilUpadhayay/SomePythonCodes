class Car:
    color = None

class Bike:
    color = None

def change_color(Car, rang): # 'Car' doesn't represents the class 'Car'. It can be any valid identifier. 
    Car.color = rang

car1 = Car()
car2 = Car()

bike1 = Bike()
bike2 = Bike()

change_color(car1, 'red')
change_color(car2, 'white')

change_color(bike1, 'blue')
change_color(bike2, 'green')

print(car1.color)
print(car2.color)

print(bike1.color)
print(bike2.color)