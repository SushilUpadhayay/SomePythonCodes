#output line A \n line B
print(r'line A \n line B')
#output \"\"
print(r'\"\"')
#output \"\'
print(r" \"\'")

#*************Or we can use this method****************
#output line A \n line B
print('line A \\n line B')
#output \"\"
print('\\"\\"')
#output \"\'
print(" \\\"\\\'")