# program to swap two elements of list
def swap(pos1,pos2,temp_list):
    length = len(temp_list)
    temp = temp_list[pos1]
    temp_list[pos1] = temp_list[pos2]
    temp_list[pos2] = temp
    return temp_list

print("This is the program to swap two elements of list given the postion of elements.")
i = 1
my_list = []
while True:
    element = input(f"If you want to add {i}th element then type your element otherwise type 'done': ")
    my_list.append(element)
    i += 1
    if element == 'done':
        my_list.remove('done')
        break

pos1 = int(input(f"Enter first position(from 1 to {len(my_list)} and exclusive): "))
pos2 = int(input(f"Enter second position((from 1 to {len(my_list)} and exclusive): "))

if pos1 == pos2 or not my_list:
    print("Can't be swap because same elements.")
elif pos1 < 1 or pos2 < 1 or pos1 > len(my_list) or pos2 > len(my_list):
    print("Tnvalid postions.")
else:
    print(f"List before swapping {my_list}.") # str.format() also known as string format
    print(f"List after swapping {swap(pos1-1,pos2-1,my_list)}.")

