# creating a object 'file' to call a read functions and manually closing the file
file = open('my_file.txt', 'r') # you can use file path also and read 'r' is the default mode while opening a file
file_content = file.read() # reading from file
print(file_content)

# creating a object 'file' to call 'read()' without manually closing the file
with open('my_file.txt', 'r') as file:
    file_content2 = file.read()

print(file_content2)