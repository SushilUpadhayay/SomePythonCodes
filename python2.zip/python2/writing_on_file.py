# opening a file in read or append mode
with open('my_file.txt', 'w') as fwrite:
    fwrite.write("Yo! What's up? Bro\nWhat are you doing?")

# openig the file in write mode
with open('my_file.txt') as fread:
    file_content = fread.read()

print(file_content)