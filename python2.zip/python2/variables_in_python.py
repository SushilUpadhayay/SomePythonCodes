"""
# Variables in python
name = "Sushil"
age = 21
age +=1
print("hello",name)
print(type(name))
print("My age name is "+name+" "+"and I'm " +str(age)+" "+"years old.")
correct = True # correct is boolean datatype.So it can only store either True or False
print(correct)"""


# multiple assignment in python
name , age , human = "Sushil" , 21 , True # not a tuple
print(name,age,human)