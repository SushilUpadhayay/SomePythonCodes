a = int(input("Enter a integer number: "))
b = int(input("Enter another integer number: "))
def sum(a,b): # Functions definition; takes argument of a and b and returns their sum
    return (a+b)
c = sum(a,b) # passing argument
print(f"Sum is {c}.")

