def print_name(name1, name2, name3): # Only accept three (fixed) arguments
    print("Hello" + " " + name1 + " " + " " + name2 + " " + name3)

print_name('sushil','kumar','upadhayay')

def sum(*args): # it accepts any arbitary number of arguments and stores them in tuple named args. 'args' can be named any valid identifier
    sum = 0 
    
    for i in args: # iterating theough tuple
        sum += i

    print(sum)

sum(50, 12, 53, 100)

