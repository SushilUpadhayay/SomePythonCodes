# It is a concept in Python, where the type or the class of an object is determined by its behavior (methods and properties) rather than its explicit type or class.
# This concept means that the suitability of an object for a particular operation is determined by the presence of certain methods and properties rather than the 
# type or class of the object itself.
# For example, in a statically typed language, you might declare a function to accept objects of a specific type. In Python, you might just assume that the object passed 
# to the function has the necessary methods, and if it doesn't, it will raise an attribute error at runtime.
# In the make_duck_quack(), it doesn't matter if the object passed in is a Dog, Cat, MallardDuck or RobotDuck as long as it has a quack(). 
# Duck typing is not affected by the presence of dissimilar methods in different classes, as long as the specific methods being used in a particular context are present

class MallardDuck:
    def quack(self):
        return "Quack"

class RobotDuck:
    def quack(self):
        return "Beep Boop Quack"

    def walk(self):
        return "Walking like a robot"

def make_duck_quack(duck):
    return duck.quack()

# Both MallardDuck and RobotDuck can be used with make_duck_quack
mallard_duck = MallardDuck()
robot_duck = RobotDuck()

print(make_duck_quack(mallard_duck))  # Output: Quack
print(make_duck_quack(robot_duck))    # Output: Beep Boop Quack
