def pattern_print():
    a = int(input("Enter either num. of rows or num. of colums: "))
    b = '*'
    for i in range(a): # To print rows
        for j in range(i+1):
            print("*", end=" ")
        print()

if __name__ == "__main__":
    pattern_print()