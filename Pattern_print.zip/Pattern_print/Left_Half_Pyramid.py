def pattern_print():
    a = int(input("Enter either num. of rows or num. of colums: "))
    for  i in range(a):
        for j in range(a-1-i):
           print("\t",end = "") 
        for k in range(i+1):
             print("*\t", end = "")
        print()
           
if __name__ == "__main__":
    pattern_print()
    
# end is used when we have to print in the same line

"""
def pattern_print():
    a = int(input("Enter either number of rows or number of columns: "))
    for i in range(a):
        print(" \t" * (a - 1 - i), end="") Do the operation " \t" by (a-1-i) times and the print statement should not end with new line character. String multiplication 
        print("*\t" * (i + 1))

if __name__ == "__main__":
    pattern_print()

The key difference is that with end=" ", there will always be at least one space between subsequent print() outputs, whereas with end="", there will be no
extra characters added between subsequent print() outputs.
"""