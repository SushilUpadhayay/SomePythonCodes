def pattern_print():
    a = int(input("Enter either num. of rows or num. of colums: "))
    for i in range(a):
        print(" "*(a-i-1),end = "  ")
        print("* "*(i+1), end = "  ")
        print()   
if __name__ == "__main__":
    pattern_print()
    