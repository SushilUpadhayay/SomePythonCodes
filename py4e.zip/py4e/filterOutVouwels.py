# Hello, World!
vowels = ['a', 'e', 'i', 'o', 'u','A', 'E', 'I', 'O', 'U']
print([letters for letters in "Hello, World!" if letters not in vowels ])