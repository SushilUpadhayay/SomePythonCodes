"""
Question 3: Convert Temperatures
Given a list of temperatures in Celsius [0, 10, 20, 34.5], write a list comprehension to convert these temperatures to 
Fahrenheit using the formula F = C * 9/5 + 32.
Example Input: [0, 10, 20, 34.5]
Example Output: [32.0, 50.0, 68.0, 94.1]

"""

input = [0, 10, 20, 34.5]
print([temp*(9/5)+32  for temp in input])