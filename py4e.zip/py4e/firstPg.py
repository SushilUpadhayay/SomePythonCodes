print([num**2 for num in range(1, 11)]) #  list comprehension that generates a list of the squares of numbers from 1 to 10. 
