"""
Write a list comprehension that generates a list of tuples where each tuple contains a number and its square for numbers from 1 to 5.

"""
print([(index, index*index )for index in range(1, 6)])














